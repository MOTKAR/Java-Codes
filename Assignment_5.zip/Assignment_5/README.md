# Employee Registration Web Application

This simple web application uses JSP, Servlet, and JDBC to register employees into a MySQL database.

## Files and structure
- `src/com/example/Employee.java` - Employee model class
- `src/com/example/DBUtil.java` - JDBC connection helper
- `src/com/example/EmployeeServlet.java` - Servlet that processes registration
- `WebContent/index.jsp` - Employee registration form
- `WebContent/success.jsp` - Success page after registration
- `WebContent/WEB-INF/web.xml` - Deployment descriptor
- `create_employee_db.sql` - SQL script to create database and table

## Database setup
1. Install MySQL server.
2. Open MySQL command line or workbench.
3. Run `create_employee_db.sql`:

```sql
CREATE DATABASE employee_db;
USE employee_db;
CREATE TABLE employees (
    id INT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    salary DOUBLE NOT NULL
);
```

4. Update `DBUtil.java` with your MySQL username and password.

## Add JDBC driver
- Download the MySQL Connector/J JAR.
- Place the JAR in your servlet container's `lib` folder (e.g. `apache-tomcat/lib`) or add it to your project classpath.

## Run the application
1. Create a Dynamic Web Project in Eclipse or use any servlet-enabled IDE.
2. Copy the `src` and `WebContent` folders into the project.
3. Deploy to Tomcat or another servlet container.
4. Open browser at `http://localhost:8080/<your-app-name>/`

## Notes
- The app validates employee ID, name, email, and salary.
- Employee ID must be between 1 and 20.
- Salary must be positive.
