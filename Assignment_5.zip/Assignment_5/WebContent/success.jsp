<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.example.Employee" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Registration Success</title>
    <style>
        body { font-family: Arial, sans-serif; background: #eef2f7; }
        .container {
            width: 420px;
            margin: 60px auto;
            padding: 24px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .success { color: #2c7a2d; }
        a { color: #007bff; text-decoration: none; }
    </style>
</head>
<body>
<div class="container">
    <h2 class="success">Employee Registered</h2>
    <p>${message}</p>
    <hr>
    <h3>Employee Details</h3>
    <table>
        <tr><td>ID:</td><td>${employee.id}</td></tr>
        <tr><td>Name:</td><td>${employee.name}</td></tr>
        <tr><td>Email:</td><td>${employee.email}</td></tr>
        <tr><td>Salary:</td><td>${employee.salary}</td></tr>
    </table>
    <p><a href="index.jsp">Register another employee</a></p>
</div>
</body>
</html>
