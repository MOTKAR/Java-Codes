<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Employee Registration</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; }
        .container {
            width: 450px;
            margin: 60px auto;
            padding: 24px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        input[type=text], input[type=number] {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background: #007bff;
            color: white;
            padding: 10px 18px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .message { color: green; }
        .error { color: red; }
    </style>
</head>
<body>
<div class="container">
    <h2>Employee Registration</h2>
    <% String error = (String) request.getAttribute("error"); %>
    <% if (error != null) { %>
        <p class="error"><%= error %></p>
    <% } %>
    <form action="employee" method="post">
        <label for="id">Employee ID (1-20)</label>
        <input type="number" id="id" name="id" min="1" max="20" required>

        <label for="name">Name</label>
        <input type="text" id="name" name="name" required>

        <label for="email">Email</label>
        <input type="text" id="email" name="email" required>

        <label for="salary">Salary</label>
        <input type="number" id="salary" name="salary" step="0.01" min="0" required>

        <button type="submit">Register Employee</button>
    </form>
</div>
</body>
</html>
