package com.example;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/employee")
public class EmployeeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idText = request.getParameter("id");
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String salaryText = request.getParameter("salary");

        String message = null;
        String error = null;

        try {
            int id = Integer.parseInt(idText);
            double salary = Double.parseDouble(salaryText);

            if (id < 1 || id > 20) {
                throw new IllegalArgumentException("Employee ID must be between 1 and 20.");
            }
            if (name == null || name.trim().isEmpty()) {
                throw new IllegalArgumentException("Name cannot be empty.");
            }
            if (email == null || email.trim().isEmpty()) {
                throw new IllegalArgumentException("Email cannot be empty.");
            }
            if (salary <= 0) {
                throw new IllegalArgumentException("Salary must be a positive value.");
            }

            Employee employee = new Employee(id, name, email, salary);
            saveEmployee(employee);
            message = "Employee registered successfully.";
            request.setAttribute("employee", employee);
        } catch (NumberFormatException e) {
            error = "Please enter valid numeric values for ID and salary.";
        } catch (IllegalArgumentException e) {
            error = e.getMessage();
        } catch (SQLException e) {
            error = "Database error: " + e.getMessage();
        }

        if (error != null) {
            request.setAttribute("error", error);
            RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
            dispatcher.forward(request, response);
        } else {
            request.setAttribute("message", message);
            RequestDispatcher dispatcher = request.getRequestDispatcher("success.jsp");
            dispatcher.forward(request, response);
        }
    }

    private void saveEmployee(Employee employee) throws SQLException {
        String sql = "INSERT INTO employees (id, name, email, salary) VALUES (?, ?, ?, ?)";
        try (Connection connection = DBUtil.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, employee.getId());
            statement.setString(2, employee.getName());
            statement.setString(3, employee.getEmail());
            statement.setDouble(4, employee.getSalary());
            statement.executeUpdate();
        }
    }
}
